Events.on(EventType.ClientLoadEvent, e=>{
    Vars.content.bullets().each(b => b instanceof BasicBulletType, b => b.frontRegion = Core.atlas.find("router"));

    var defBundle = I18NBundle.createBundle(Core.files.internal("bundles/bundle"));
    router = Character.toString(Iconc.blockRouter);
    for(s in bundle.getKeys()){
        bundle.getProperties().put(s, Strings.stripColors(defBundle.get(s)).replaceAll("\\S", router));
    }
});
// BulletType
    