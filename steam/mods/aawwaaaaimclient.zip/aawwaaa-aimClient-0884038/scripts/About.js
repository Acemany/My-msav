module.exports=(MainWindow,childs,Manager)=>{
    let t=new Table();
    let str=
    "AimClient "+Manager.version+"-"+Manager.versionType+"\n"
    + "By awa"
    + "LICENSE: MIT"
    t.add(str);
    childs.about={
        name:"@about",
        icon:Core.atlas.drawable("aimclient-info"),
        hasChild:false,
        info:t
    }
}