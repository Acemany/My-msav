require("frags/Main")
module.exports=(MainWindow,childs,Manager)=>{
    require("frags/Main").init(MainWindow,childs,Manager)
}